﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
$mutex = New-Object System.Threading.Mutex($false, 'Global\MBOX-PrintBridge-Upgrade')
$held = $false
try {
  try { $held = $mutex.WaitOne(0) } catch [System.Threading.AbandonedMutexException] { $held = $true }
  if (-not $held) { throw '升级或试打窗口正在运行，请先查看该窗口。' }
  $manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
  if ($manifest.version -ne '1.0.11' -or $manifest.packageRevision -ne 'r1') { throw '试打包版本不符。' }
  foreach ($file in $manifest.files.psobject.Properties.Name) {
    if ((Get-FileHash -LiteralPath (Join-Path $PSScriptRoot $file) -Algorithm SHA256).Hash -ne $manifest.files.psobject.Properties[$file].Value) { throw '试打文件校验失败。' }
  }
  $catalog = @(Get-Content -LiteralPath (Join-Path $PSScriptRoot 'test-catalog.json') -Raw -Encoding UTF8 | ConvertFrom-Json)
  if ($catalog.Count -ne 15) { throw '试打目录不完整。' }
  $queues = @(Get-Printer -ErrorAction Stop | Sort-Object Name | Select-Object -ExpandProperty Name)
  if ($queues.Count -eq 0) { throw '未找到已安装打印机。' }
  $form = New-Object Windows.Forms.Form
  $form.Text = 'M-BOX 结账预览核验：只试打，不安装'
  $form.ClientSize = New-Object Drawing.Size(500,245)
  $form.StartPosition = 'CenterScreen'; $form.FormBorderStyle = 'FixedDialog'; $form.MaximizeBox = $false
  $labels = @('选择原吧台或后厨打印机','票据类型（每次只打印一张测试票）','实际纸宽')
  $combos = @()
  for ($i=0; $i -lt 3; $i++) {
    $label = New-Object Windows.Forms.Label; $label.Text = $labels[$i]; $label.AutoSize = $true
    $label.Location = New-Object Drawing.Point(15,(10+$i*60)); $form.Controls.Add($label)
    $combo = New-Object Windows.Forms.ComboBox; $combo.DropDownStyle = 'DropDownList'
    $combo.Location = New-Object Drawing.Point(15,(30+$i*60)); $combo.Width = 465
    $form.Controls.Add($combo); $combos += $combo
  }
  foreach ($queue in $queues) { [void]$combos[0].Items.Add($queue) }
  foreach ($entry in $catalog) { [void]$combos[1].Items.Add([string]$entry.label) }
  $combos[1].SelectedIndex = 0
  $combos[2].Items.AddRange([object[]]@('80毫米','58毫米')); $combos[2].SelectedIndex = 0
  $ok = New-Object Windows.Forms.Button; $ok.Text = '打印一张'; $ok.Location = New-Object Drawing.Point(275,200)
  $ok.DialogResult = [Windows.Forms.DialogResult]::OK; $form.Controls.Add($ok)
  $cancel = New-Object Windows.Forms.Button; $cancel.Text = '取消'; $cancel.Location = New-Object Drawing.Point(385,200)
  $cancel.DialogResult = [Windows.Forms.DialogResult]::Cancel; $form.Controls.Add($cancel); $form.CancelButton = $cancel
  if ($form.ShowDialog() -ne 'OK') { return }
  if ($combos[0].SelectedIndex -lt 0) { throw '未选择打印机，未提交试打。' }
  $queue = [string]$combos[0].SelectedItem
  $mode = $combos[1].SelectedIndex
  $profile = if ($combos[2].SelectedIndex -eq 1) { 'escpos_58' } else { 'escpos_80' }
  if ((Get-Printer -Name $queue -ErrorAction Stop).PrinterStatus -match 'Error|Offline|PaperProblem|NoToner') { throw '打印机当前不可用。' }
  if (@(Get-PrintJob -PrinterName $queue -ErrorAction Stop).Count -gt 0) { throw '打印队列还有任务，请等票据出完再试。' }
  $source = [IO.File]::ReadAllText((Join-Path $PSScriptRoot 'bridge.mjs'),[Text.Encoding]::UTF8)
  $logo = [regex]::Match($source,"const RECEIPT_HEADER_LOGO_BITS = '([^']+)'").Groups[1].Value
  if ([Convert]::FromBase64String($logo).Length -ne 1152) { throw 'Logo数据无效。' }
  $stateDir = Join-Path $env:LOCALAPPDATA 'MBOX-PrintBridge-111-r1'
  [void][IO.Directory]::CreateDirectory($stateDir)
  $sha = [Security.Cryptography.SHA256]::Create()
  $key = ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes("$queue|$mode|$profile")))).Replace('-',''); $sha.Dispose()
  $marker = Join-Path $stateDir ($key+'.json')
  if (Test-Path -LiteralPath $marker) { throw '该打印机和票据类型已尝试过本次试打，请先核对纸票，避免重复出纸。' }
  $record = @{ queue=$queue; candidate='1.0.11-r1'; mode=$mode; state='attempting'; time=(Get-Date).ToString('o') }
  $time = [TimeZoneInfo]::ConvertTimeBySystemTimeZoneId([DateTime]::UtcNow,'China Standard Time').ToString('yyyy-MM-dd HH:mm:ss')
  $title = [string]$combos[1].SelectedItem
  $layoutFile = [string]$catalog[$mode].file
  if ($layoutFile -notmatch '^test-[a-z_]+\.layout\.json$') { throw '试打文件名无效。' }
  $text = [IO.File]::ReadAllText((Join-Path $PSScriptRoot $layoutFile),[Text.Encoding]::UTF8).Replace('{{PRINT_TIME}}',$time)
  $ticketPath = Join-Path $stateDir ($key+'.txt')
  [IO.File]::WriteAllText($ticketPath,$text,(New-Object Text.UTF8Encoding($false)))
  $tokens=$null;$parseErrors=$null
  $rendererAst=[Management.Automation.Language.Parser]::ParseFile((Join-Path $PSScriptRoot 'print-ticket.ps1'),[ref]$tokens,[ref]$parseErrors)
  if($parseErrors.Count){throw '打印程序解析失败，未试打。'}
  foreach($fn in $rendererAst.FindAll({param($n) $n-is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name-in @('New-EscPosTicketBytes','New-StructuredEscPosTicketBytes','Add-ReceiptHeaderLogo')},$true)){
    . ([scriptblock]::Create($fn.Extent.Text))
  }
  $previewBytes=New-EscPosTicketBytes -Text $text -TicketProfile $profile -HeaderLogoBits $logo -Structured
  $hasher=[Security.Cryptography.SHA256]::Create()
  $actualHash=([BitConverter]::ToString($hasher.ComputeHash($previewBytes))).Replace('-','').ToLowerInvariant();$hasher.Dispose()
  $expectedHash=$catalog[$mode].rawSha256.psobject.Properties[$profile].Value
  if($actualHash-ne $expectedHash){throw '打印字节与预览不一致，已阻止试打。'}
  $record | ConvertTo-Json | Set-Content -LiteralPath $marker -Encoding UTF8
  & (Join-Path $PSScriptRoot 'print-ticket.ps1') -QueueName $queue -ContentPath $ticketPath -DocumentName 'MBOX-LAYOUT-111-TEST-NOT-ORDER' -Profile $profile -Copies 1 -HeaderLogoBits $logo -Structured
  $record.state = 'submitted_not_physically_verified'
  $record | ConvertTo-Json | Set-Content -LiteralPath $marker -Encoding UTF8
  [void][Windows.Forms.MessageBox]::Show('已提交一张测试票。请核对Logo、中文、字号、金额和切纸；原营业程序未替换。','M-BOX 试打结果')
} catch {
  [void][Windows.Forms.MessageBox]::Show("未能确认试打完成：$($_.Exception.Message)`r`n不自动重试，请先核实是否出纸。",'M-BOX 试打提示')
} finally {
  if ($held) { $mutex.ReleaseMutex() }; $mutex.Dispose()
}
