﻿param(
  [Parameter(Mandatory=$true)][string]$QueueName,
  [Parameter(Mandatory=$true)][string]$ContentPath,
  [Parameter(Mandatory=$true)][string]$DocumentName,
  [Parameter(Mandatory=$true)][ValidateSet('escpos_58','escpos_80','windows_text')][string]$Profile,
  [Parameter(Mandatory=$true)][ValidateRange(1,5)][int]$Copies,
  [switch]$Compact,
  [switch]$CompactItems,
  [string]$HeaderLogoBits = '',
  [switch]$Structured
)

$ErrorActionPreference = 'Stop'

# Venue-verified RAW transport restored from the user backup (2026-09-09).
# Do not substitute Windows font drawing for this transport without device acceptance.
$printer = Get-Printer -Name $QueueName -ErrorAction Stop
if ($printer.PrinterStatus -match 'Error|Offline|PaperProblem|NoToner') {
  throw "printer_unavailable:$($printer.PrinterStatus)"
}

$content = [System.IO.File]::ReadAllText($ContentPath, [System.Text.Encoding]::UTF8)
if ([string]::IsNullOrWhiteSpace($content)) {
  throw 'empty_ticket_content'
}

if (-not ('MboxRawPrinter' -as [type])) {
  Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;

public static class MboxRawPrinter {
  [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
  private class DOCINFOW {
    [MarshalAs(UnmanagedType.LPWStr)] public string pDocName;
    [MarshalAs(UnmanagedType.LPWStr)] public string pOutputFile;
    [MarshalAs(UnmanagedType.LPWStr)] public string pDatatype;
  }

  [DllImport("winspool.Drv", EntryPoint = "OpenPrinterW", SetLastError = true, CharSet = CharSet.Unicode)]
  private static extern bool OpenPrinter(string src, out IntPtr hPrinter, IntPtr pd);

  [DllImport("winspool.Drv", EntryPoint = "ClosePrinter", SetLastError = true)]
  private static extern bool ClosePrinter(IntPtr hPrinter);

  [DllImport("winspool.Drv", EntryPoint = "StartDocPrinterW", SetLastError = true, CharSet = CharSet.Unicode)]
  private static extern int StartDocPrinter(IntPtr hPrinter, int level, [In] DOCINFOW di);

  [DllImport("winspool.Drv", EntryPoint = "EndDocPrinter", SetLastError = true)]
  private static extern bool EndDocPrinter(IntPtr hPrinter);

  [DllImport("winspool.Drv", EntryPoint = "StartPagePrinter", SetLastError = true)]
  private static extern bool StartPagePrinter(IntPtr hPrinter);

  [DllImport("winspool.Drv", EntryPoint = "EndPagePrinter", SetLastError = true)]
  private static extern bool EndPagePrinter(IntPtr hPrinter);

  [DllImport("winspool.Drv", EntryPoint = "WritePrinter", SetLastError = true)]
  private static extern bool WritePrinter(IntPtr hPrinter, IntPtr pBytes, int dwCount, out int dwWritten);

  public static void SendBytes(string printerName, string documentName, byte[] payload) {
    if (string.IsNullOrWhiteSpace(printerName)) throw new ArgumentException("printerName");
    if (payload == null || payload.Length == 0) throw new ArgumentException("payload");

    IntPtr hPrinter;
    if (!OpenPrinter(printerName, out hPrinter, IntPtr.Zero)) {
      throw new InvalidOperationException("open_printer_failed:" + Marshal.GetLastWin32Error());
    }

    try {
      DOCINFOW di = new DOCINFOW();
      di.pDocName = string.IsNullOrWhiteSpace(documentName) ? "M-BOX Ticket" : documentName;
      di.pOutputFile = null;
      di.pDatatype = "RAW";

      if (StartDocPrinter(hPrinter, 1, di) <= 0) {
        throw new InvalidOperationException("start_doc_failed:" + Marshal.GetLastWin32Error());
      }
      try {
        if (!StartPagePrinter(hPrinter)) {
          throw new InvalidOperationException("start_page_failed:" + Marshal.GetLastWin32Error());
        }
        try {
          IntPtr unmanaged = Marshal.AllocHGlobal(payload.Length);
          try {
            Marshal.Copy(payload, 0, unmanaged, payload.Length);
            int written;
            if (!WritePrinter(hPrinter, unmanaged, payload.Length, out written) || written != payload.Length) {
              throw new InvalidOperationException("write_printer_failed:" + Marshal.GetLastWin32Error());
            }
          } finally {
            Marshal.FreeHGlobal(unmanaged);
          }
        } finally {
          EndPagePrinter(hPrinter);
        }
      } finally {
        EndDocPrinter(hPrinter);
      }
    } finally {
      ClosePrinter(hPrinter);
    }
  }
}
'@
}

function Add-ReceiptHeaderLogo {
  param($chunks, [string]$HeaderLogoBits, [string]$BrandBits = '', [int]$BrandWidth = 0)
  $logo = [Convert]::FromBase64String($HeaderLogoBits)
  if ($logo.Length -ne 1152) { throw 'invalid_receipt_header_logo' }
  $imageWidth = 96
  if ($BrandBits) {
    if ($BrandWidth -notin @(384,504)) { throw 'invalid_receipt_brand_width' }
    $logo = [Convert]::FromBase64String($BrandBits)
    if ($logo.Length -ne ($BrandWidth * 12)) { throw 'invalid_receipt_brand_bitmap' }
    $imageWidth = $BrandWidth
  }
  $stride = [int]($imageWidth / 8)
  $gbk = [Text.Encoding]::GetEncoding(936)
    $chunks.AddRange([byte[]](0x1B, 0x33, 24))
    for ($band = 0; $band -lt 4; $band++) {
      $chunks.AddRange([byte[]](0x1B, 0x2A, 33, ($imageWidth -band 255), ($imageWidth -shr 8)))
      for ($x = 0; $x -lt $imageWidth; $x++) {
        for ($block = 0; $block -lt 3; $block++) {
          [byte]$column = 0
          for ($bit = 0; $bit -lt 8; $bit++) {
            $y = $band * 24 + $block * 8 + $bit
            $offset = $y * $stride + [int][Math]::Floor($x / 8)
            if (($logo[$offset] -band (128 -shr ($x % 8))) -ne 0) {
              $column = $column -bor (128 -shr $bit)
            }
          }
          $chunks.Add($column)
        }
      }
      if ($band -eq 1 -and -not $BrandBits) { $chunks.AddRange($gbk.GetBytes('  M-BOX · SHANGHAI')) }
      $chunks.Add(0x0A)
    }
    $chunks.AddRange([byte[]](0x1B, 0x32))
}

function New-StructuredEscPosTicketBytes {
  param([string]$Text, [string]$TicketProfile, [string]$HeaderLogoBits)
  $layout = $Text | ConvertFrom-Json
  if ($layout.schemaVersion -ne 1 -or $null -eq $layout.rows) { throw 'invalid_receipt_layout' }
  $gbk = [Text.Encoding]::GetEncoding(936)
  $chunks = New-Object Collections.Generic.List[byte]
  $chunks.AddRange([byte[]](0x1B,0x40,0x1B,0x74,0,0x1B,0x61,0))
  if ($HeaderLogoBits) {
    $brandKey = if ($TicketProfile -eq 'escpos_58') { 'escpos_58' } else { 'escpos_80' }
    $brandWidth = if ($TicketProfile -eq 'escpos_58') { 384 } else { 504 }
    $brandBits = if ($null -ne $layout.headerBrandBits) { [string]$layout.headerBrandBits.$brandKey } else { '' }
    Add-ReceiptHeaderLogo -chunks $chunks -HeaderLogoBits $HeaderLogoBits -BrandBits $brandBits -BrandWidth $brandWidth
  }
  $lineWidth = if ($TicketProfile -eq 'escpos_58') { 32 } else { 42 }
  # One normal text row is 24 dots; enlarged text sets its own minimum height.
  $chunks.AddRange([byte[]](0x1B,0x33,24))
  function Split-ReceiptText([string]$Value, [int]$Width) {
    $clean = ($Value -replace '[\x00-\x1F\x7F]', ' ').Replace([string][char]0x00A5,[string][char]0xFFE5)
    $parts = New-Object Collections.Generic.List[string]
    $part = ''; $used = 0
    $elements = [Globalization.StringInfo]::GetTextElementEnumerator($clean)
    while ($elements.MoveNext()) {
      $element = $elements.GetTextElement(); $count = $gbk.GetByteCount($element)
      if ($used -gt 0 -and $used+$count -gt $Width) { $parts.Add($part); $part=''; $used=0 }
      $part += $element; $used += $count
    }
    $parts.Add($part)
    return $parts.ToArray()
  }
  function Add-ReceiptRow([string]$Value, [int]$Size=0, [bool]$Bold=$false, [int]$Align=0) {
    if ($Size -notin @(0,17,34) -or $Align -notin @(0,1,2)) { throw 'invalid_receipt_style' }
    $chunks.AddRange([byte[]](0x1B,0x61,$Align,0x1D,0x21,$Size,0x1B,0x45,[int]$Bold))
    $width = [int][Math]::Floor($lineWidth/(1+($Size -shr 4)))
    foreach ($part in @(Split-ReceiptText $Value $width)) {
      $chunks.AddRange($gbk.GetBytes($part)); $chunks.Add(10)
    }
    $chunks.AddRange([byte[]](0x1B,0x61,0,0x1D,0x21,0,0x1B,0x45,0))
  }
  foreach ($row in $layout.rows) {
    switch ([string]$row.type) {
      'rule' { Add-ReceiptRow ('-' * $lineWidth) }
      'text' { Add-ReceiptRow ([string]$row.text) ([int]$row.size) ([bool]$row.bold) ([int]$row.align) }
      'venue' {
        $key = if ($TicketProfile -eq 'escpos_58') { 'escpos_58' } else { 'escpos_80' }
        $width = if ($TicketProfile -eq 'escpos_58') { 384 } else { 504 }
        $bitmap = $row.profiles.$key
        if ([int]$bitmap.width -ne $width -or [int]$bitmap.height -ne 48) { throw 'invalid_venue_bitmap_size' }
        $bits = [Convert]::FromBase64String([string]$bitmap.bits)
        $stride = [int]($width / 8)
        if ($bits.Length -ne $stride * 48) { throw 'invalid_venue_bitmap_data' }
        $chunks.AddRange([byte[]](0x1B,0x61,0,0x1D,0x21,0,0x1B,0x45,0,0x1B,0x33,24))
        for ($band=0; $band -lt 2; $band++) {
          $chunks.AddRange([byte[]](0x1B,0x2A,33,($width -band 255),($width -shr 8)))
          for ($x=0; $x -lt $width; $x++) {
            for ($block=0; $block -lt 3; $block++) {
              [byte]$column=0
              for ($bit=0; $bit -lt 8; $bit++) {
                $y=$band*24+$block*8+$bit
                $offset=$y*$stride+[int][Math]::Floor($x/8)
                if (($bits[$offset] -band (128 -shr ($x % 8))) -ne 0) { $column=$column -bor (128 -shr $bit) }
              }
              $chunks.Add($column)
            }
          }
          $chunks.Add(10)
        }
      }
      'productionColumns' {
        if (@($row.cells).Count -ne 2 -or [int]$row.size -notin @(0,17)) { throw 'invalid_production_columns' }
        $size = [int]$row.size
        $width = [int][Math]::Floor($lineWidth/(1+($size -shr 4)))
        $nameWidth = $width-6
        $left = @(Split-ReceiptText ([string]$row.cells[0]) $nameWidth)
        $right = @(Split-ReceiptText ([string]$row.cells[1]) 5)
        $count = [Math]::Max($left.Count,$right.Count)
        for ($i=0; $i -lt $count; $i++) {
          $a=if($i-lt $left.Count){$left[$i]}else{''}
          $b=if($i-lt $right.Count){$right[$i]}else{''}
          $line=$a+(' '*($nameWidth-$gbk.GetByteCount($a)))+' '+(' '*(5-$gbk.GetByteCount($b)))+$b
          Add-ReceiptRow $line $size ([bool]$row.bold)
        }
      }
      'columns' {
        if (@($row.cells).Count -ne 3) { throw 'invalid_receipt_columns' }
        $widths = @(($lineWidth-17),5,10)
        $left = @(Split-ReceiptText ([string]$row.cells[0]) $widths[0])
        $middle = @(Split-ReceiptText ([string]$row.cells[1]) $widths[1])
        $right = @(Split-ReceiptText ([string]$row.cells[2]) $widths[2])
        $count = [Math]::Max($left.Count,[Math]::Max($middle.Count,$right.Count))
        for ($i=0; $i -lt $count; $i++) {
          $a=if($i-lt $left.Count){$left[$i]}else{''}
          $b=if($i-lt $middle.Count){$middle[$i]}else{''}
          $c=if($i-lt $right.Count){$right[$i]}else{''}
          $line = $a + (' ' * ($widths[0]-$gbk.GetByteCount($a))) + ' ' + (' ' * ($widths[1]-$gbk.GetByteCount($b))) + $b + ' ' + (' ' * ($widths[2]-$gbk.GetByteCount($c))) + $c
          Add-ReceiptRow $line 0 ([bool]$row.bold)
        }
      }
      default { throw 'invalid_receipt_row' }
    }
  }
  $chunks.AddRange([byte[]](0x1B,0x32,10,10,10,0x1D,0x56,1))
  return ,$chunks.ToArray()
}

function New-EscPosTicketBytes {
  param([string]$Text, [string]$TicketProfile, [switch]$Compact, [switch]$CompactItems, [string]$HeaderLogoBits = '', [switch]$Structured)
  if ($Structured) { return ,(New-StructuredEscPosTicketBytes -Text $Text -TicketProfile $TicketProfile -HeaderLogoBits $HeaderLogoBits) }
  if ([string]::IsNullOrWhiteSpace($Text)) { throw 'empty_ticket_content' }
  $gbk = [System.Text.Encoding]::GetEncoding(936)
  $chunks = New-Object System.Collections.Generic.List[byte]
  # Keep the venue-proven initialization, code table and left alignment.
  $chunks.AddRange([byte[]](0x1B, 0x40, 0x1B, 0x74, 0x00, 0x1B, 0x61, 0x00))
  $normalized = ($Text -replace "`r`n", "`n" -replace "`r", "`n").TrimEnd()
  # Ticket data cannot inject ESC/POS commands. Preserve printable data and newlines.
  $normalized = ($normalized -replace "`t", '    ') -replace '[\x00-\x09\x0B-\x1F\x7F]', ''
  $normalized = $normalized.Replace([string][char]0x00A5, [string][char]0xFFE5)
  if ($HeaderLogoBits) {
    $logo = [Convert]::FromBase64String($HeaderLogoBits)
    $headerEnd = $normalized.IndexOf("`n")
    if ($logo.Length -ne 1152 -or $headerEnd -lt 0 -or $normalized.Substring(0, $headerEnd) -ne 'M-BOX · SHANGHAI') {
      throw 'invalid_receipt_header_logo'
    }
    $normalized = $normalized.Substring($headerEnd + 1)
    # Four 24-dot column-format bands; native GBK text alongside the second band.
    # Restore ordinary line spacing before the existing ticket body.
    Add-ReceiptHeaderLogo -chunks $chunks -HeaderLogoBits $HeaderLogoBits
  }
  $lineWidth = if ($TicketProfile -eq 'escpos_58') { 32 } else { 42 }
  foreach ($line in ($normalized -split "`n")) {
    $label = $line.TrimStart()
    [byte]$size = 0
    [byte]$bold = 0
    # Daily reports use the smallest scale of the existing venue-tested character
    # mode (1x1). Keep the established GBK font and other ticket emphasis unchanged.
    if (-not $Compact) {
      if ($label -match '^(桌台|桌号)：') { $size=0x22; $bold=1 }
      elseif ($label -match '^(合计|净收|应收|应付)：') { $size=0x11; $bold=1 }
      elseif (-not $CompactItems -and $label -match '×\d+\s*$') { $size=0x11; $bold=1 }
      elseif ($label -match '^备注：') { $bold=1 }
    }
    $chunks.AddRange([byte[]](0x1D, 0x21, $size, 0x1B, 0x45, $bold))
    $width = [int][Math]::Floor($lineWidth / (1 + ($size -shr 4)))
    $used = 0
    $elements = [Globalization.StringInfo]::GetTextElementEnumerator($line)
    while ($elements.MoveNext()) {
      $bytes = $gbk.GetBytes($elements.GetTextElement())
      if ($used -gt 0 -and $used + $bytes.Length -gt $width) { $chunks.Add(0x0A); $used=0 }
      $chunks.AddRange($bytes); $used += $bytes.Length
    }
    $chunks.Add(0x0A)
    if ($size -gt 0) { $chunks.Add(0x0A) }
    # Explicit reset prevents emphasis leaking into subsequent fields/jobs.
    $chunks.AddRange([byte[]](0x1D, 0x21, 0x00, 0x1B, 0x45, 0x00))
  }
  # Identical feed-and-half-cut suffix to the working venue script.
  $chunks.AddRange([byte[]](0x0A, 0x0A, 0x0A, 0x1D, 0x56, 0x01))
  return ,$chunks.ToArray()
}

$payload = New-EscPosTicketBytes -Text $content -TicketProfile $Profile -Compact:$Compact -CompactItems:$CompactItems -HeaderLogoBits $HeaderLogoBits -Structured:$Structured
for ($i = 1; $i -le $Copies; $i++) {
  $docName = if ($Copies -gt 1) { "$DocumentName#$i" } else { $DocumentName }
  [MboxRawPrinter]::SendBytes($QueueName, $docName, $payload)
}
